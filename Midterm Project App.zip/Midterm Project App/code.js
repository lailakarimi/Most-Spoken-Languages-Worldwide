// Variables :)
var languages = getColumn("Most Spoken Languages Worldwide", "Language");
var branches = getColumn("Most Spoken Languages Worldwide", "Branch");
var speakers = getColumn("Most Spoken Languages Worldwide", "Speakers in millions");
var rank = getColumn("Most Spoken Languages Worldwide", "Rank");
var branchOptions = "Branches";
var speakersOptions = "Speakers in Millions";
var rankOptions = "Rank";

var filteredbranchesList = [];
var filteredspeakersList = [];
var filteredrankList = [];


// go from start screen to branches screen
onEvent("startButton", "click", function( ) {
  setScreen("branchesScreen");
  soundEffectButton();
});

// go from start screen to reccsongs 2 screen --> mak
onEvent("restartsongButton", "click", function( ){
  setScreen("reccsongs2Screen");
  soundEffectButton();
});


// go back from branches screen to start screen
onEvent("backstartButton", "click", function( ){
  setScreen("startScreen");
  soundEffectButton();
});

// dropdown for branches
onEvent("branchesDropdown", "change", function( ) {
  filteredbranchesList = [];
  var index = 0;
  branchOptions = getText("branchesDropdown");
  for (var i = 0; i < branches.length; i++) {
    if (branchOptions == branches[i]) {
      index = i;
      appendItem(filteredbranchesList, languages[i]);
    }
  }
  setText("branchesOutput", filteredbranchesList);
});

// go from branches screen to speakers screen
onEvent("branchesButton", "click", function( ) {
  setScreen("speakersScreen");
  soundEffectButton();
});

// go back from speakers screen to branches screen
onEvent("backbranchesButton", "click", function( ) {
  setScreen("branchesScreen");
  soundEffectButton();
});

// dropdown for speakers in millions
onEvent("speakersDropdown", "change", function( ) {
  filteredspeakersList = [];
  var index = 0;
  speakersOptions = getText("speakersDropdown");
  for (var i = 0; i < speakers.length; i++) {
    if (speakersOptions == speakers[i]) {
      index = i;
      appendItem(filteredspeakersList, languages[i]);
    }
  }
  setText("speakersOutput", filteredspeakersList);
});

// go from speakers screen to rank screen
onEvent("speakersButton", "click", function( ) {
  setScreen("rankScreen");
  soundEffectButton();
});

// go back from rank screen to speakers screen
onEvent("backspeakersButton", "click", function( ) {
  setScreen("speakersScreen");
  soundEffectButton();
});

// dropdown for rank
onEvent("rankDropdown", "change", function( ) {
  filteredrankList = [];
  var index = 0;
  rankOptions = getText("rankDropdown");
  for (var i = 0; i < rank.length; i++) {
    if (rankOptions == rank[i]) {
      index = i;
      appendItem(filteredrankList, languages[i]);
    }
  }
  setText("rankOutput", filteredrankList);
});

// go from rank screen to reccsongs screen
onEvent("rankButton", "click", function( ) {
  setScreen("reccsongsScreen");
  soundEffectButton();
});

// >>Separate data set I made called Top 20 Songs solely for the reccsongs Screen>>

// Variables :)
var languageTopSongs = getColumn("Top 15 Songs", "Language");
var songTopSongs = getColumn("Top 15 Songs", "Song");
var songOptions = "Song";
var filteredsongList = [];

// reccsongs dropdown
onEvent("reccsongsDropdown", "change", function( ) {
  filteredsongList = [];
  var index = 0;
  songOptions = getText("reccsongsDropdown");
  for (var i = 0; i < songTopSongs.length; i++) {
    if (songOptions == languageTopSongs[i]) {
      index = i;
      appendItem(filteredsongList, songTopSongs[i]);
    }
  }
  setText("reccsongsOutput", filteredsongList);
 
});


// go back from reccsongs screen to rank screen
onEvent("backrankButton", "click", function( ) {
  setScreen("speakersScreen");
  soundEffectButton();
});

// go from reccsongs screen to reccsongs2 screen
onEvent("reccsongsButton", "click", function( ) {
  setScreen("reccsongs2Screen");
  soundEffectButton();
});

// reccsongs 2 screen, allows you to play each song for each language

// plays Regular by WayV
onEvent("mchineseButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674053711.mp3", false);
});

// plays Como Mirarte by Sebastian Yatra
onEvent("spanishButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674053753.mp3", false);
});

// plays September by Earth Wind & Fire
onEvent("englishButton", "click", function( ) {
playSound("assets/RPReplay_Final1674263950.mp3", false);
});

// plays Tum Se Hi by Pritam, Mohair Chauhan
onEvent("hindiButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674053846.mp3", false);
});

// plays Aye Deke Jaa by Arijit Singh
onEvent("bengaliButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674053901.mp3", false);
});

// plays Parado no Bailão by MC L da Vinte, MC Gury
onEvent("portugueseButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674053954.mp3", false);
});

// plays 360° by Eldzhey
onEvent("russianButton","click", function( ) {
  playSound("assets/RPReplay_Final1674054008.mp3", false);
});

// plays Shinunoga E-Wa by Fujii Kaze
onEvent("japaneseButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674054124.mp3", false);
});

// plays Na Na by Mickey Singh, Jonita Gandhi
onEvent("wpunjabButton","click", function( ) {
  playSound("assets/RPReplay_Final1674054194.mp3", false);
});

// plays Dewak Jalji Re by Ajay
onEvent("marathiButton","click", function( ) {
  playSound("assets/RPReplay_Final1674054266.mp3", false);
});

// plays Adirindey by Sanjith Hegde
onEvent("teluguButton","click", function( ) {
  playSound("assets/RPReplay_Final1674054356.mp3", false);
});

// plays Grain in Ear by Mang Chủng
onEvent("wuchineseButton","click", function( ) {
  playSound("assets/RPReplay_Final1674054397.mp3", false);
});

// plays Emri Olur by Mustafa Ceceli
onEvent("turkishButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674054455.mp3", false);
});

// plays Euphoria by BTS
onEvent("koreanButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674054497.mp3", false);
});

// plays Papaoutai by Stromae
onEvent("frenchButton", "click", function( ) {
  playSound("assets/RPReplay_Final1674054555.mp3", false);
});

// go back from reccsongs2 screen to reccsongs screen
onEvent("backreccsongsButton", "click", function( ) {
  setScreen("reccsongsScreen");
  soundEffectButton();

});

// go from reccsongs 2 screen to start screen
onEvent("homeButton", "click", function( ) {
  setScreen("startScreen");
  soundEffectButton();
});

// allows the sound effect to play without having to code the whole thing every single time
function soundEffectButton() {
  playSound("assets/category_tap/level_select_1.mp3", false);
}

 
// Code Ends! (finally lol)
